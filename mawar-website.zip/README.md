# 🌹 Mawar Website

Website sederhana bertema bunga mawar.

## Fitur
- Informasi tentang mawar
- Makna warna mawar
- Desain sederhana dan elegan

## Cara Menjalankan
Cukup buka file `index.html` di browser.

## Author
Gudhal Production
